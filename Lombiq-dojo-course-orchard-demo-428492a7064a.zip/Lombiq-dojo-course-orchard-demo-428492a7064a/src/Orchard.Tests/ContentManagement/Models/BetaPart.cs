using Orchard.ContentManagement;

namespace Orchard.Tests.ContentManagement.Models {
    public class BetaPart : ContentPart {
    }
}