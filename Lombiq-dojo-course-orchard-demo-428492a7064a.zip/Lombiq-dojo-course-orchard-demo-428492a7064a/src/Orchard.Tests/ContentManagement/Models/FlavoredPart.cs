﻿using Orchard.ContentManagement;

namespace Orchard.Tests.ContentManagement.Models {
    public class FlavoredPart : ContentPart {
    }
}
